const express = require('express');
const bodyParser = require('body-parser');
const ejs = require("ejs");
const https = require('https');
const mongoose=require('mongoose')
const app=express();
var name;
app.use(express.static("public"));
mongoose.connect("mongodb://localhost:27017/kratin",{useNewUrlParser:true,useUnifiedTopology: true});
const credSchema={
  name:String,
  mobile:String,
  password:String,
};
const Cred=mongoose.model("Cred",credSchema);
const heathSchema={
  Date:Date,
  SbloodP:Number,
  DbloodP:Number,
  heartRate:Number,
  spo:Number,
  sleeptime:Number,
  user:String
};
const Heath=mongoose.model("Heath",heathSchema);
app.use(bodyParser.urlencoded({extended:true}));
app.set("view engine","ejs");
app.get("/",function(req,res){
  res.render("index");
});
app.post("/",function(req,res){
  name=req.body.username;
  var password=req.body.password;
  Cred.findOne({name:name,pass:password},function(err,resul){
      Heath.find({user:name},function(err,cred){
        var l=cred.length-1;
        if(l<0){
          last={}
        }else{last=cred[l];}
        if(cred){res.render("show",{name:name,cred:cred,last:last})}
        else{res.render("add",{name:name})}
      });

   });
});
app.get("/add",function(req,res){
  name=req.query.name;
  res.render("add",{name:name});
});
app.post("/add",function(req,res){
  name=req.body.name;
  console.log(name);
  const heath = new Heath({
  Date:req.body.Date,
  SbloodP:req.body.sbp,
  DbloodP:req.body.dbp,
  spo:req.body.sp,
  sleeptime:req.body.sl,
  heartRate:req.body.hr,
  user:name
  });
  heath.save(function(err){
    if(!err){
      Heath.find({user:name},function(err,cred){
        var l=cred.length-1;
        if(cred){res.render("show",{name:name,cred:cred,last:cred[l]})}
        else{res.render("show",{name:name})}
      });
    }
  })


});
app.get("/show",function(req,res){
  res.render("show",{name:req.body.name});
})

app.post("/signup",function(req,res){
  const cred = new Cred({
    name: req.body.name,
    mobile: req.body.mob,
    password:req.body.pass
  });
  cred.save(function(err){
  if (!err){
    res.render("index");
  }
});
});
app.get("/signup",function(req,res){
  res.render("signup");
});
app.listen(3000);
